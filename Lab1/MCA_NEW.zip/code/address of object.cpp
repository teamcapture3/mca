#include<iostream.h>
#include<conio.h>
class Number
{
int num;
public:
	Number()
	{
	  num=0;
	}
};
void main()
{
clrscr();
Number n;
cout<<&n;
getch();
}