#include<iostream.h>
#include<conio.h>
#include<string.h>
#include<stdio.h>
void main()
{
    clrscr();
    char s1[30], s2[30], result[100];

    cout << "Enter string s1: ";
    gets(s1);

    cout << "Enter string s2: ";
    gets(s2);

    cout << "Resultant String = "<<strcat(s1, s2);;

    getch();
}