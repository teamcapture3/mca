#include<iostream.h>
#include<conio.h>
class Num
{
private:
int a,b,c,d;
public:
void input();
void show();
Num operator+(Num);//replace + with -/*or / for -/+or / operator overloading
};
void Num::input()
{
	cout<<"\nEnter values for a,b,c and d:";
	cin>>a>>b>>c>>d;
}
void Num::show()
{
	cout<<"A="<<a<<" B="<<b<<" C="<<c<<" D="<<d<<endl;
}
Num Num :: operator+(Num t)//replace + with -/*or / for -/+or / operator overloading
{
Num tmp;
tmp.a=a+t.a;//replace + with -/*or / for -/+or / operator overloading
tmp.b=b+t.b;//replace + with -/*or / for -/+or / operator overloading
tmp.c=c+t.c;//replace + with -/*or / for -/+or / operator overloading
tmp.d=d+t.d;//replace + with -/*or / for -/+or / operator overloading
return(tmp);
}
void main()
{
clrscr();
Num x,y,z;
cout<<"\nObject X";
x.input();
cout<<"\nObject Y";
y.input();
z=x+y;//replace + with -/*or / for -/+or / operator overloading
cout<<"\nX:";
x.show();
cout<<"\nY:";
y.show();
cout<<"\nZ:";
z.show();
getch();
}