#include<iostream.h>
#include<conio.h>
void swap(int &num1,int &num2)
{
	int temp;
	temp=num1;
	num1=num2;
	num2=temp;
	cout<<"After swapping :"<<endl;
	cout<<"1st num :"<<num1<<" and 2nd num :"<<num2;
}
void main()
{
clrscr();
int num1,num2;
cout<<"enter 1st number :";
cin>>num1;
cout<<"enter 2nd number :";
cin>>num2;
cout<<"before swapping : 1st num :"<<num1<<" and 2nd num :"<<num2<<endl;
swap(num1,num2);
getch();
}