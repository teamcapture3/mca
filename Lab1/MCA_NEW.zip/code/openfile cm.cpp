#include<iostream.h>
#include<conio.h>
#include<fstream.h>
#include<string.h>
void main()
{
    clrscr();
    ifstream fin;
    char ch;
    char *wo="\n";
    fin.open("4bFile.txt");
    while(fin)
    {
	fin.get(ch);
	if(ch==*wo)
	{
		cout<<endl;
	}
	else
	{
		cout<<ch;
	}
    }
    fin.close();
    getch();
}