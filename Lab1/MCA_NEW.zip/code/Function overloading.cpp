#include<iostream.h>
#include<conio.h>
int add(int,int);
float add(float,float);
double add(double,double);
void main()
{
clrscr();
int intNum1,intNum2,ansInt;
float floatNum1,floatNum2,ansFloat;
double doubleNum1,doubleNum2,ansDouble;
cout<<"Enter 1st integer number :";
cin>>intNum1;
cout<<"Enter 2nd integer number :";
cin>>intNum2;
cout<<"Enter 1st float number :";
cin>>floatNum1;
cout<<"Enter 2nd float number :";
cin>>floatNum2;
cout<<"Enter 1st double number :";
cin>>doubleNum1;
cout<<"Enter 2nd double number :";
cin>>doubleNum2;
ansInt=add(intNum1,intNum2);
cout<<"Addition of integer nos. :"<<ansInt<<endl;
ansFloat=add(floatNum1,floatNum2);
cout<<"Addition of float nos.:"<<ansFloat<<endl;
ansDouble=add(doubleNum1,doubleNum2);
cout<<"addition of double nos."<<ansDouble<<endl;
getch();
}
int add(int a,int b)
{
	return a+b;
}
float add(float a,float b)
{
	return a+b;
}
double add(double a,double b)
{
	return a+b;
}