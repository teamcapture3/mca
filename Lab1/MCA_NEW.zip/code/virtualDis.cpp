#include<iostream.h>
#include<conio.h>
class Base
{
	public :
       virtual	~Base()
	{
		cout<<"Base destructor";
	}
};
class Derived :public Base
{
	public:
	~Derived()
	{
		cout<<"Derived Destructor"<<endl;
	}
};
void main()
{
	clrscr();
	Base* b=new Derived;
	delete b;
	getch();
}
