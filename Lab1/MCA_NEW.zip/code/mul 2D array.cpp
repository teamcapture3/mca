#include<iostream.h>
#include<conio.h>
void main()
{
clrscr();
int matrixA[2][2],matrixB[2][2];
int sum[2][2];
	for(int i=0;i<2;i++)
	{
		for(int j=0;j<2;j++)
		{
			cout<<"Enter "<<i<<j<<" element of 1st matrix:";
			cin>>matrixA[i][j];
		}
	}
	for(int l=0;l<2;l++)
	{
		for(int j=0;j<2;j++)
		{
			cout<<"Enter "<<l<<j<<" element of 2nd matrix :";
			cin>>matrixB[l][j];
		}
	}
	for(int k=0;k<2;k++)
	{
		for(int j=0;j<2;j++)
		{
		      sum[k][j]=matrixA[k][j]+matrixB[k][j];
		}
	}
	cout<<"Addition is :"<<endl;
	for(int n=0;n<2;n++)
	{
		for(int j=0;j<2;j++)
		{
		cout<<sum[n][j]<<"\t";
		}
		cout<<endl;
	}
getch();
}