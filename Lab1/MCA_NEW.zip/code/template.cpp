#include<iostream.h>
#include<conio.h>
#include<stdlib.h>
const int max=3;
template<class T>
class Stack
{
private:
T st[max];
int top;
public :
Stack()
{
top=-1;
}
void push(T var)
{
st[++top]=var;
}
T pop()
{
return st[top--];
}
};
int main()
{
int i;
Stack<float>s1;
Stack<long>s2;
Stack<int>s3;
clrscr();
cout<<"----STACK WITH FLOAT VALUES----"<<endl;
s1.push(9.3);
s1.push(4.6);
s1.push(3.9);
for(i=0;i<max;i++)
cout<<s1.pop()<<"\t";
cout<<endl<<"\n----STACK WITH LONG VALUES----"<<endl;
s2.push(23092902);
s2.push(46578930);
s2.push(39999000);
for(i=0;i<max;i++)
cout<<s2.pop()<<"\t";
cout<<endl<<"\n----STACK WITH INT VALUES----"<<endl;
s3.push(78);
s3.push(183);
s3.push(1415);
for(i=0;i<max;i++)
cout<<s3.pop()<<"\t";
getch();
return 0;
}
