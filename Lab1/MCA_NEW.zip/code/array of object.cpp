#include<iostream.h>
#include<conio.h>
const int size=3;
class books
{
char tit1e [30];
float price ;
public:
	void getdata ()
	{
		cout<<"Enter the Title:�;
		cin>>title;
		cout<<"Enter the Price:�;
		cin>>price;
	}
	void putdata ()
	{
		cout<<"Title:"<<title<< "\n";
		cout<<"Price:"<<price<< "\n�;
	}

} ;	
	int main ()
	{
	clrscr();
	books book[size] ;
	for(int i=0;i<size;i++)
	{
		cout<<"Enter details of book "<<(i+1)<<"\n";
		book[i].getdata();
	}
	for(int i=0;i<size;i++)
	{
		cout<<"\nBook "<<(i+l)<<"\n";
		book[i].putdata() ;
	}
	getch();
	return 0;
}