#include<iostream.h>
#include<conio.h>

inline float add(float x,float y)
{
return x+y;
}

inline float sub(float x,float y)
{
return x-y;
}

inline float mul(float x,float y)
{
return x*y;
}

void main()
{       
	clrscr();
	float a,b;
	cout<<"Enter the numbers:";
	cin>>a>>b;
	cout<<"Addition of the number is:"<<endl<<add(a,b);
	cout<<"Subtraction of the number is:"<<endl<<sub(a,b);
	cout<<"Multiplication of the number is:"<<endl<<mul(a,b);
	getch();
}






