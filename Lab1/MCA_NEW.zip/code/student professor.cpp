#include<iostream.h>
#include<conio.h>
class Data
{
	public:
	virtual void getStudentData()=0;
	virtual void getProfessorData()=0;
};
class Conditions:public Data
{
	private:
	char name[30];float gpa;int publications;
	public:
	void getStudentData()
	{
	       cout<<"Enter student's name :";
	       cin>>name;
	       cout<<"Enter student's GPA :";
	       cin>>gpa;
	       if(gpa>3.5)
	       {
			cout<<name<<" is outstanding"<<endl;
	       }
	}
	void getProfessorData()
	{
		cout<<"Enter name of professor:";
		cin>>name;
		cout<<"Enter number of publications :";
		cin>>publications;
		if(publications>20)
		{
			cout<<name<<" is outstanding"<<endl;
		}
	}
};
void main()
{
	clrscr();
	Conditions con;
	int check;
	cout<<"Enter 1 for student and 2 for professor"<<endl;
	cout<<"1.Student	2.Professor"<<endl;
	cin>>check;
	if(check==1)
	{
		con.getStudentData();
	}
	else if(check==2)
	{
		con.getProfessorData();
	}
	else
	{
		cout<<"invalid option"<<endl;
	}
	getch();
}