#include<iostream.h>
#include<conio.h>

void main( )
{
	clrscr();
	char str[80];
	
	cout << "Enter a string: ";
	cin.getline(str,80);
	
	int words = 0; // Holds number of words
	
	for(int i = 0; str[i] != '\0'; i++)
	{
		if (str[i] == ' ') //Checking for spaces
		{
			words++;
		} 		
	}

	cout << "The number of words = " << words+1 << endl;

	getch();
}