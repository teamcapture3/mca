#include<iostream.h>
#include<conio.h>
void main()
{
clrscr();
int num[5]={1,2,3,4,5};
int *ptr;
for(int i=0;i<5;i++)
{
ptr=&num[i];
cout<<*ptr<<endl;
}
getch();
}