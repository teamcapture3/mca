#include<iostream.h>
#include<fstream.h>
#include<iomanip.h>
#include<stdlib.h>
#include<conio.h>
class Person
{
private:
char name[20];
int age;
public:
void getData()
{
cout<<"Enter Name : ";
cin>>name;
cout<<endl;
cout<<"Enter Age : ";
cin>>age;
cout<<endl;
}
void putData()
{
cout<<setiosflags(ios::left)<<setw(15)<<name;
cout<<setiosflags(ios::right)<<setw(8)<<age<<endl;
}
void add(fstream &f)
{
f.clear();
(*this).getData();
f.write((char *) &(*this),sizeof (*this));
cout<<"Record added successfully."<<endl;
}
void update(fstream &f)
{
int obj;
cout<<"Enter record number to update : ";
cin>>obj;
cout<<endl;
int loc=(obj-1)*sizeof((*this));
f.seekp(loc);
if(f.eof())
f.clear();
cout<<"-----Enter New Values-----"<<endl;
(*this).getData();
f.write((char *) &(*this),sizeof (*this))<<flush;
cout<<"Record updated successfully."<<endl;
}
void display(fstream &f)
{
cout<<"Contents of the file are : "<<endl;
cout<<"---------------------------\n";
f.seekg(0,ios::beg);
while(f.read((char*) &(*this),sizeof (*this)))
{
(*this).putData();
}
}
void count(fstream &f)
{
f.seekg(0,ios::end);
int last=f.tellg();
int n=last/sizeof((*this));
cout<<"Number of object : "<<n<<endl;
}
};
int main()
{
Person p;
int ch;
char ans;
fstream f;
clrscr();
f.open("Person.dat",ios::ate|ios::in|ios::out|ios::binary);
do
{
cout<<"1. Add Detail"<<endl;
cout<<"2. Modify Detail"<<endl;
cout<<"3. Display Detail"<<endl;
cout<<"4. Count number of objects"<<endl;
cout<<"5. Exit"<<endl;
cout<<"Enter a valid choice:"<<endl;
cin>>ch;
switch(ch)
{
case 1:
p.add(f);
break;
case 2:
p.update(f);
break;
case 3:
p.display(f);
break;
case 4:
p.count(f);
break;
case 5:
f.close();
exit(0);
default:
cout<<"You entered wrong choice."<<endl;
}
cout<<"Do you want to continue (y/n)?";
cin>>ans;
cout<<endl;
}while(ans=='y'||ans=='Y');
return 0;
}