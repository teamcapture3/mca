#include<conio.h>
#include<iostream.h>
double convertToCM(double *inch)
{
double a;double result;
a=*inch;
result=a*2.54;
return result;
}
void main()
{
clrscr();
double inch;
double answer;
cout<<"enter a value in inches :";
cin>>inch;
answer=convertToCM(&inch);
cout<<inch<<" inches="<<answer<<" centimetres";
getch();
}