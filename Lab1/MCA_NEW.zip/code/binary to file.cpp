#include<iostream.h>
#include<conio.h>
#incldue<fstream.h>
#define FILE_NAME "person.dat"

class Person
{
	char name[50];  
	int age;
public: 
	void getData()
	{
		cout<<"Enter the name:"<<endl;
		cin>>name;
		cout<<"Enter your Age:"<<endl; 
		cin>>age;
	}
	void setData()
	{
		cout<<"Name:"<<name<<endl;
		cout<"Age:"<<age<<endl;
	}
};

void main()
{
 clrscr();
 Person obj;
 obj.getData();

 	fstream file;
 	file.open(FILE_NAME,ios::out|ios::binary);
  	if(!file)
	{
	 	cout<<"Error in creating file...\n";
	}
	
	file.write((char*)&emp,sizeof(emp));
	file.close();
	cout<<"Date saved into the file.\n";
	
	//open file again 
	file.open(FILE_NAME,ios::in|ios::binary);
	if(!file)
	{
		cout<<"Error in opening file...\n";
	}
	
	if(file.read((char*)&emp,sizeof(emp)))
	{
		cout<<endl<<endl;
		cout<<"Data extracted from file..\n";
		//print the object
		obj.setData();
	}
	else
	{
		cout<<"Error in reading data from file...\n";
	}
	
	file.close();	
	getch();
}