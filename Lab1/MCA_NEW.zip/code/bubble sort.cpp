#include<iostream.h>
#include<conio.h>
void order(int num[])
{
	int i, j, flag = 1;
	int temp;
	for(i = 1; (i <= 10) && flag; i++)
	{
		flag = 0;
		for (j=0; j < (10 -1); j++)
		{
			if (num[j+1] > num[j])
			{
				temp = num[j];
				num[j] = num[j+1];
				num[j+1] = temp;
				flag = 1;
			}
		}
	}
	cout<<"After sorting :"<<endl;
	for(int k=0;k<10;k++)
	{
		cout<<num[k]<<endl;
	}
}
void main()
{
clrscr();
	int num[10]={1,3,8,76,56,4,34,87,20,30};
	order(num);
	getch();
}