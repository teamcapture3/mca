#include<iostream.h>
#include<fstream.h>
#include<string.h>
#include<conio.h>

void main()
{
string Item[5];
int arrCost[5];
char ch;
char *line="\n";
    for(int i=0;i<5;i++)
    {
        cout<<"enter item "<<i+1<<":";
        cin>>Item[i];
        cout<<"enter cost of "<<Item[i]<<":";
        cin>>arrCost[i];
    }
ofstream writeFile;
writeFile.open("items.txt");
    for(int k=0;k<5;k++)
    {
        writeFile<<Item[k];
        writeFile<<"\t";
        writeFile<<arrCost[k]<<endl;
    }
ifstream readFile;
readFile.open("items.txt");
cout<<"Your entered information:"<<endl;
    while(readFile)
    {
        readFile.get(ch);
        if(ch==*line)
        {
            cout<<endl;
        }
        else
        {
            cout<<ch;
        }
    }
}
