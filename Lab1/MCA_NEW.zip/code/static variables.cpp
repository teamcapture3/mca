#include<iostream.h>
#include<conio.h>
class Test
{
private : static int count;
public:
	void display()
	{
		count++;
		cout<<count<<endl;
	}
};
int Test::count=0;
void main()
{
clrscr();
Test t;
t.display();
t.display();
t.display();
t.display();
t.display();
getch();
}