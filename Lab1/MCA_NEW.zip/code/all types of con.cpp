#include<iostream.h>
#include<conio.h>
class constructor_1
{
	private :
	int a,b;
	public:
	constructor_1()
	{
		cout<<"default constructor"<<endl;
		a=1;
		b=2;
		cout<<"a :"<<a<<" b:"<<b<<endl;
	}
	constructor_1(int x,int y)
	{
		cout<<"parameterized constructor"<<endl;
		a=x;b=y;
		cout<<"a :"<<a<<"b :"<<b<<endl;
	}
	constructor_1(const constructor_1 &obj2)
	{
		cout<<"copy constructor"<<endl;
		a=obj2.a;
		b=obj2.b;
		cout<<"a :"<<a<<"b :"<<b<<endl;
	}
};
void main()
{
clrscr();
constructor_1 obj1;
constructor_1(3,4);
constructor_1 obj2=obj1;
getch();
}