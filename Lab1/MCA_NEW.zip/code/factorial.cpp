#include<iostream.h>
#include<conio.h>
int factorial(int num)
{
	int a=num;
	int temp;
	if(a<=1)
	{
	return 1;
	}
	temp=a*factorial(a-1);
	return temp;
}
void main()
{
int num,ans;
clrscr();
cout<<"Enter a number :";
cin>>num;
ans=factorial(num);
cout<<"Factorial is :"<<ans;
getch();
}